<style>
li {
}
em {
  text-decoration: line-through;
}
strong {
color: #ff80b2;
}
</style>
###2010-11-25###
* _make geoip.close better_

###2010-11-28###
* Add asynchronous methods to City object

###v0.2.0###
* re-factory the whole direcoty
* add more module other then country and City
* add db_type check in every module

###v0.2.1###
* Try in added ASNUM file supporting  
* Make org_by_add method return an arrary of string rather than a strang object

###v0.3.0###
* make clear why org_by_domain method dose not works
* use javasript Error type as err
* add all asynchronous methods

###v0.3.1###
* Precise latitude and langitude to 7 digit

###v0.3.2###
* add data type checking method

###Future###
* add document to npm package(use npm doc command?)
* Make open and close method better
* Stick 0.3.* for ever?
* make clear why org_by_domain method dose not works?
* Support IPv6?

###v0.5###
* binding to geoip C library 1.4.7
* works with new v8 api / uv compatibility layer
